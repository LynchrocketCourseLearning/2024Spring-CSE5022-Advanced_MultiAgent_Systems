package tileworld;


import repast.simphony.context.Context;
import repast.simphony.context.space.continuous.ContinuousSpaceFactory;
import repast.simphony.context.space.continuous.ContinuousSpaceFactoryFinder;
import repast.simphony.context.space.grid.GridFactory;
import repast.simphony.context.space.grid.GridFactoryFinder;
import repast.simphony.dataLoader.ContextBuilder;
import repast.simphony.random.RandomHelper;
import repast.simphony.space.continuous.ContinuousSpace;
import repast.simphony.space.continuous.NdPoint;
import repast.simphony.space.continuous.RandomCartesianAdder;
import repast.simphony.space.grid.Grid;
import repast.simphony.space.grid.GridBuilderParameters;
import repast.simphony.space.grid.SimpleGridAdder;
import repast.simphony.space.grid.WrapAroundBorders;

public class TileWorldContext implements ContextBuilder<Object> {
	@Override
	public Context build(Context<Object> context) {
		
		context.setId("tileworld");
		
		ContinuousSpaceFactory spaceFactory = ContinuousSpaceFactoryFinder.createContinuousSpaceFactory(null);
		ContinuousSpace<Object> space =  spaceFactory.createContinuousSpace("space", context,
				new RandomCartesianAdder<Object>(),
				new repast.simphony.space.continuous.WrapAroundBorders(), 100, 50);

		GridFactory gridFactory = GridFactoryFinder.createGridFactory(null);
		Grid<Object> grid = gridFactory.createGrid("grid", context,
				new GridBuilderParameters<Object>( new WrapAroundBorders(),
				new SimpleGridAdder<Object>(),
				true, 100, 50));
		
		//Populate the context
		int agents = 5;
		int holes = 10;
		int tiles = 5;
		int home = 1;
		
		//Add agents
		for (int i = 0; i < home; i++) {
			int energy = RandomHelper.nextIntFromTo(4, 10);
			context.add(new Home(space, grid,energy));
			}
		
		//Add agents
		for (int i = 0; i < agents; i++) {
			context.add(new Agent(space, grid,500,i+1));
		}
		
		//Add holes
		for (int i = 0; i < holes; i++) {
			context.add(new Hole(space, grid, 0));
		}
		
		//Add Tiles
		for (int i = 0; i < tiles; i++) {
			context.add(new Tile(space, grid));
		}
		
		for(Object obj: context) {
			NdPoint pt = space.getLocation(obj);
			
			/*if (obj instanceof Home) {
				//grid.moveTo(obj, 1, 1);
			} else {*/
				grid.moveTo(obj, (int)pt.getX(), (int)pt.getY());
			//}
			
		}
				
		return context;
	}

}
