package tileworld;

import java.awt.Color;
import java.util.ArrayList;
import java.util.List;

import repast.simphony.context.Context;
import repast.simphony.engine.schedule.ScheduledMethod;
import repast.simphony.query.space.grid.GridCell;
import repast.simphony.query.space.grid.GridCellNgh;
import repast.simphony.random.RandomHelper;
import repast.simphony.space.SpatialMath;
import repast.simphony.space.continuous.ContinuousSpace;
import repast.simphony.space.continuous.NdPoint;
import repast.simphony.space.grid.Grid;
import repast.simphony.space.grid.GridPoint;
import repast.simphony.util.ContextUtils;
import repast.simphony.util.SimUtilities;
import repast.simphony.visualizationOGL2D.DefaultStyleOGL2D;

public class Agent{
	//private Context<Object> context;
	private int id;
	private ContinuousSpace<Object> space;
	private Grid<Object> grid;
	private int energy_level, startingEnergy;
	private List<Tile> currentTiles;
	private List<Hole> currentHoles;
	private int score;
	
	public Agent(ContinuousSpace<Object> space, Grid<Object> grid, int energy, int id) {
		this.id = id;
		this.space = space;
		this.grid = grid;
		this.energy_level = startingEnergy = energy;
		this.score = 0;
		this.currentTiles = new ArrayList<Tile>();
		this.currentHoles = new ArrayList<Hole>();
	}

	@ScheduledMethod(start=1, interval=1)
	public void step() {
		GridPoint pt = grid.getLocation(this);
		int tilesCollected = 0;
		GridCellNgh<Tile> nghCreator = new GridCellNgh<>(grid, pt, Tile.class, 5, 5);
		List<GridCell<Tile>> gridCells = nghCreator.getNeighborhood(true);
		SimUtilities.shuffle(gridCells, RandomHelper.getUniform());
		GridPoint tileSport = null;
		int maxCount = -1;
		for (GridCell<Tile> cell : gridCells) {
			if(cell.size() > maxCount) {
				tileSport = cell.getPoint();
				maxCount = cell.size();
			}
		}
		moveTowardsTile(tileSport);
		pickTile();
		putTiles_Holes();
		
		if (this.currentTiles.size() >0) {
			tilesCollected = this.currentTiles.size();
		}
		System.out.print("Agent "+this.id+" score: "+this.energy_level+" tiles: "+tilesCollected+" \n\n");
	}
		

	public void moveTowardsTile(GridPoint pt) {
		if(!pt.equals(grid.getLocation(this))) {
			NdPoint mypoint = space.getLocation(this);
			NdPoint otherPoint = new NdPoint(pt.getX(), pt.getY());
			double angle = SpatialMath.calcAngleFor2DMovement(space, mypoint, otherPoint);
			space.moveByVector(this, 1, angle,0);
			mypoint = space.getLocation(this);
			grid.moveTo(this, (int)mypoint.getX(), (int)mypoint.getY());

		}
	}
	
	public void pickTile() {
		GridPoint pt = grid.getLocation(this);
		List<Object> tiles = new ArrayList<Object>();		
		for (Object obj: grid.getObjectsAt(pt.getX(), pt.getY())) {
			if(obj instanceof Tile) {
				Tile tile = (Tile)obj;
				tiles.add(obj);

			}
		}
		
		if (tiles.size() > 0) {
			int index = RandomHelper.nextIntFromTo(0, tiles.size()-1);
			Object obj = tiles.get(index);
			
			this.currentTiles.add((Tile) obj);
			//Tile location
			Context<Object> context = ContextUtils.getContext(obj);
			context.remove(obj);			
			
		}
		
	}
	
	public void putTiles_Holes() {
		//Implement logic for put tiles in holes and get rewards 
		
	}
	
	 
	//public void 
	/*public List<Tuple> Sense(){
		
	}*/

	
	

}
